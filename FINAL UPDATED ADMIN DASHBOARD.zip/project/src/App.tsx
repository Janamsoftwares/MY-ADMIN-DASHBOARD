import React, { useState, useEffect } from 'react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';
import RegisterUser from './components/RegisterUser';
import ManageUsers from './components/ManageUsers';
import Renewals from './components/Renewals';
import InvoiceGenerator from './components/InvoiceGenerator';
import WebsiteBookings from './components/WebsiteBookings';
import Settings from './components/Settings';
import { User, Booking } from './types';
import { storageUtils } from './utils/storage';
import { getSampleUsers, getSampleBookings } from './utils/sampleData';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentSection, setCurrentSection] = useState('dashboard');
  const [users, setUsers] = useState<User[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    // Check if user is already logged in
    const loggedIn = localStorage.getItem('adminLoggedIn') === 'true';
    setIsLoggedIn(loggedIn);

    // Load data from localStorage or use sample data
    const savedUsers = storageUtils.getUsers();
    const savedBookings = storageUtils.syncWebsiteBookings(); // Use sync method

    if (savedUsers.length === 0) {
      // If no users in storage, load sample data
      const sampleUsers = getSampleUsers();
      setUsers(sampleUsers);
      storageUtils.saveUsers(sampleUsers);
    } else {
      setUsers(savedUsers);
    }

    if (savedBookings.length === 0) {
      // If no bookings in storage, load sample data
      const sampleBookings = getSampleBookings();
      setBookings(sampleBookings);
      storageUtils.saveBookings(sampleBookings);
    } else {
      setBookings(savedBookings);
    }

    // Set up periodic sync for new website bookings
    const syncInterval = setInterval(() => {
      const latestBookings = storageUtils.syncWebsiteBookings();
      if (latestBookings.length !== bookings.length) {
        setBookings(latestBookings);
      }
    }, 5000); // Check every 5 seconds

    return () => clearInterval(syncInterval);
  }, []);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    Swal.fire({
      title: 'Logout?',
      text: 'Are you sure you want to logout?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, logout',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.removeItem('adminLoggedIn');
        setIsLoggedIn(false);
        setCurrentSection('dashboard');
        Swal.fire({
          title: 'Goodbye!',
          text: 'You have been logged out.',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white'
        });
      }
    });
  };

  const handleAddUser = (user: User) => {
    const updatedUsers = [...users, user];
    setUsers(updatedUsers);
    storageUtils.saveUsers(updatedUsers);
  };

  const handleUpdateUser = (userId: string, updates: Partial<User>) => {
    const updatedUsers = users.map(user => 
      user._id === userId ? { ...user, ...updates } : user
    );
    setUsers(updatedUsers);
    storageUtils.saveUsers(updatedUsers);
  };

  const handleDeleteUser = (userId: string) => {
    const updatedUsers = users.map(user => 
      user._id === userId ? { ...user, isDeleted: true } : user
    );
    setUsers(updatedUsers);
    storageUtils.saveUsers(updatedUsers);
  };

  const handleRenewUser = (userId: string, amount: number) => {
    const updatedUsers = users.map(user => 
      user._id === userId 
        ? {
            ...user,
            subscriptionAmount: amount,
            paidSubscription: true,
            paymentDate: dayjs().format('YYYY-MM-DD'),
            expiryDate: dayjs().add(30, 'days').format('YYYY-MM-DD')
          }
        : user
    );
    setUsers(updatedUsers);
    storageUtils.saveUsers(updatedUsers);
  };

  const handleRefreshBookings = () => {
    // Sync with latest bookings from website
    const latestBookings = storageUtils.syncWebsiteBookings();
    setBookings(latestBookings);
    console.log('Bookings refreshed from website submissions');
  };

  const handleUpdateBooking = (bookingId: string, updates: Partial<Booking>) => {
    const updatedBookings = bookings.map(booking =>
      booking.id === bookingId ? { ...booking, ...updates } : booking
    );
    setBookings(updatedBookings);
    storageUtils.saveBookings(updatedBookings);
  };

  const handleDeleteBooking = (bookingId: string) => {
    const updatedBookings = bookings.filter(booking => booking.id !== bookingId);
    setBookings(updatedBookings);
    storageUtils.saveBookings(updatedBookings);
  };

  const handleAddBooking = (booking: Booking) => {
    const updatedBookings = [...bookings, booking];
    setBookings(updatedBookings);
    storageUtils.saveBookings(updatedBookings);
  };

  const renderContent = () => {
    switch (currentSection) {
      case 'dashboard':
        return <Dashboard users={users} bookings={bookings} />;
      case 'register-user':
        return <RegisterUser onAddUser={handleAddUser} />;
      case 'manage-users':
        return (
          <ManageUsers 
            users={users} 
            onDeleteUser={handleDeleteUser}
            onUpdateUser={handleUpdateUser}
            onRenewUser={handleRenewUser}
          />
        );
      case 'renewals':
        return <Renewals users={users} onRenewUser={handleRenewUser} />;
      case 'invoice-generator':
        return <InvoiceGenerator users={users} />;
      case 'website-bookings':
        return (
          <WebsiteBookings 
            bookings={bookings} 
            onRefreshBookings={handleRefreshBookings}
            onUpdateBooking={handleUpdateBooking}
            onDeleteBooking={handleDeleteBooking}
            onAddBooking={handleAddBooking}
          />
        );
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard users={users} bookings={bookings} />;
    }
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-purple-100 via-blue-50 to-indigo-100">
      <Sidebar 
        currentSection={currentSection}
        onNavigate={setCurrentSection}
        onLogout={handleLogout}
      />
      
      <main className="flex-1 p-8 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;