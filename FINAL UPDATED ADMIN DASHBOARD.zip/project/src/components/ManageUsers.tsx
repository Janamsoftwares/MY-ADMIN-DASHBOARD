import React, { useState } from 'react';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';
import { Edit, Trash2, Check, X, RefreshCw, ArrowUp, Save, Eye } from 'lucide-react';
import { User } from '../types';

interface ManageUsersProps {
  users: User[];
  onDeleteUser: (userId: string) => void;
  onUpdateUser?: (userId: string, updates: Partial<User>) => void;
  onRenewUser?: (userId: string, amount: number) => void;
}

const ManageUsers: React.FC<ManageUsersProps> = ({ 
  users, 
  onDeleteUser, 
  onUpdateUser,
  onRenewUser 
}) => {
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [viewingUser, setViewingUser] = useState<User | null>(null);
  const [editForm, setEditForm] = useState<Partial<User>>({});
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  const activeUsers = users.filter(u => !u.isDeleted);

  const handleEdit = (user: User) => {
    setEditingUser(user._id);
    setEditForm(user);
  };

  const handleSaveEdit = () => {
    if (!editingUser) return;

    onUpdateUser?.(editingUser, editForm);
    setEditingUser(null);
    setEditForm({});
    
    Swal.fire({
      title: 'Success!',
      text: 'User details updated successfully!',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const handleCancelEdit = () => {
    setEditingUser(null);
    setEditForm({});
  };

  const handleDelete = (userId: string) => {
    const user = users.find(u => u._id === userId);
    if (!user) return;

    Swal.fire({
      title: 'Are you sure?',
      text: `Delete ${user.name}? This action cannot be undone!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    }).then((result) => {
      if (result.isConfirmed) {
        onDeleteUser(userId);
        Swal.fire({
          title: 'Deleted!',
          text: 'User has been deleted.',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white'
        });
      }
    });
  };

  const handleRenewSubscription = (userId: string, currentAmount: number) => {
    Swal.fire({
      title: 'Renew Subscription',
      html: `
        <div class="text-left">
          <label class="block text-sm font-medium text-gray-700 mb-2">Renewal Amount (KSH)</label>
          <input type="number" id="renewalAmount" value="${currentAmount}" class="w-full p-3 border rounded-lg" placeholder="Enter amount">
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Renew',
      cancelButtonText: 'Cancel',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      preConfirm: () => {
        const amount = (document.getElementById('renewalAmount') as HTMLInputElement)?.value;
        if (!amount || parseInt(amount) <= 0) {
          Swal.showValidationMessage('Please enter a valid amount');
          return false;
        }
        return parseInt(amount);
      }
    }).then((result) => {
      if (result.isConfirmed) {
        onRenewUser?.(userId, result.value);
        Swal.fire({
          title: 'Success!',
          text: 'Subscription renewed successfully!',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white'
        });
      }
    });
  };

  const handleUpgradePackage = (userId: string) => {
    const packages = [
      { name: 'Bronze Plan - Up to 5 Mbps', amount: 1500 },
      { name: 'Silver Plan - Up to 10 Mbps', amount: 2000 },
      { name: 'Gold Plan - Up to 15 Mbps', amount: 2500 },
      { name: 'Platinum Plan - Up to 20 Mbps', amount: 3000 },
      { name: 'Super Plan - Up to 35 Mbps', amount: 4500 },
      { name: 'Dedicated Link - Up to 200 Mbps', amount: 8000 }
    ];

    const packageOptions = packages.map(pkg => 
      `<option value="${pkg.amount}" style="color: #374151; background: white;">${pkg.name} (KSH ${pkg.amount}/Month)</option>`
    ).join('');

    Swal.fire({
      title: 'Upgrade Package',
      html: `
        <div class="text-left">
          <label class="block text-sm font-medium text-gray-700 mb-2">Select New Package</label>
          <select id="packageSelect" class="w-full p-3 border rounded-lg" style="color: #374151; background: white;">
            <option value="" style="color: #6B7280;">Choose a package</option>
            ${packageOptions}
          </select>
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Upgrade',
      cancelButtonText: 'Cancel',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      preConfirm: () => {
        const select = document.getElementById('packageSelect') as HTMLSelectElement;
        const amount = select?.value;
        const packageName = select?.options[select.selectedIndex]?.text;
        
        if (!amount) {
          Swal.showValidationMessage('Please select a package');
          return false;
        }
        return { amount: parseInt(amount), packageName };
      }
    }).then((result) => {
      if (result.isConfirmed) {
        const updates = {
          subscriptionAmount: result.value.amount,
          package: result.value.packageName.split(' (')[0],
          paymentDate: dayjs().format('YYYY-MM-DD'),
          expiryDate: dayjs().add(30, 'days').format('YYYY-MM-DD'),
          paidSubscription: true
        };
        
        onUpdateUser?.(userId, updates);
        Swal.fire({
          title: 'Success!',
          text: 'Package upgraded successfully!',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white'
        });
      }
    });
  };

  const exportToCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Name,Phone,Location,Package,Subscription Amount,Router Cost,Payment Date,Expiry Date,Status\n"
      + activeUsers.map(user => 
        `"${user.name}","${user.phone}","${user.location}","${user.package}","${user.subscriptionAmount}","${user.routerCost || 0}","${user.paymentDate}","${user.expiryDate}","${user.paidSubscription ? 'Paid' : 'Unpaid'}"`
      ).join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `dr-net-users-${dayjs().format('YYYY-MM-DD')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    Swal.fire({
      title: 'Success!',
      text: 'Users exported to CSV successfully!',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const packages = [
    'Bronze Plan - Up to 5 Mbps (Ksh 1,500/Month)',
    'Silver Plan - Up to 10 Mbps (Ksh 2,000/Month)',
    'Gold Plan - Up to 15 Mbps (Ksh 2,500/Month)',
    'Platinum Plan - Up to 20 Mbps (Ksh 3,000/Month)',
    'Super Plan - Up to 35 Mbps (Ksh 4,500/Month)',
    'Dedicated Link - Up to 200 Mbps (Contact for Quote)'
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Manage Users
        </h3>
        <button
          onClick={exportToCSV}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg transform hover:-translate-y-1"
        >
          <span className="mr-2">📥</span> Export to CSV
        </button>
      </div>
      
      <div className="relative overflow-hidden bg-gradient-to-br from-white via-gray-50 to-blue-50 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/20">
        {/* Decorative background */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-purple-200/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-blue-200/20 to-transparent rounded-full blur-2xl"></div>
        
        <div className="relative z-10 space-y-4">
          {activeUsers.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No users registered yet.</p>
          ) : (
            activeUsers.map(user => (
              <div key={user._id} className="relative overflow-hidden bg-gradient-to-r from-white via-gray-50 to-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-200/50">
                {/* Card decorative elements */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-indigo-100/30 to-transparent rounded-full blur-xl"></div>
                
                {editingUser === user._id ? (
                  // Edit Mode
                  <div className="relative z-10 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                        <input
                          type="text"
                          value={editForm.name || ''}
                          onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <input
                          type="text"
                          value={editForm.phone || ''}
                          onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                        <input
                          type="text"
                          value={editForm.location || ''}
                          onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Package</label>
                        <select
                          value={editForm.package || ''}
                          onChange={(e) => setEditForm({ ...editForm, package: e.target.value })}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                        >
                          {packages.map(pkg => (
                            <option key={pkg} value={pkg} className="text-gray-900 bg-white">{pkg}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Subscription Amount</label>
                        <input
                          type="number"
                          value={editForm.subscriptionAmount || ''}
                          onChange={(e) => setEditForm({ ...editForm, subscriptionAmount: parseInt(e.target.value) })}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Router Cost</label>
                        <input
                          type="number"
                          value={editForm.routerCost || ''}
                          onChange={(e) => setEditForm({ ...editForm, routerCost: parseInt(e.target.value) })}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                        />
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={editForm.paidSubscription || false}
                        onChange={(e) => setEditForm({ ...editForm, paidSubscription: e.target.checked })}
                        className="w-4 h-4 text-indigo-600"
                      />
                      <label className="text-sm text-gray-700">Paid Subscription</label>
                    </div>
                    <div className="flex space-x-3">
                      <button
                        onClick={handleSaveEdit}
                        className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save Changes</span>
                      </button>
                      <button
                        onClick={handleCancelEdit}
                        className="bg-gradient-to-r from-gray-500 to-gray-600 text-white px-6 py-3 rounded-lg hover:from-gray-600 hover:to-gray-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                      >
                        <X className="w-4 h-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  // View Mode
                  <div className="relative z-10">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h5 className="font-semibold text-lg text-gray-800">{user.name}</h5>
                          <span className={`px-3 py-1 text-xs rounded-full font-medium ${
                            user.paidSubscription 
                              ? 'bg-gradient-to-r from-green-100 to-emerald-100 text-green-700' 
                              : 'bg-gradient-to-r from-red-100 to-pink-100 text-red-700'
                          }`}>
                            {user.paidSubscription ? 'Paid' : 'Unpaid'}
                          </span>
                        </div>
                        <p className="text-gray-600 font-medium">{user.phone} • {user.location}</p>
                        <p className="text-sm text-gray-500">{user.package}</p>
                        <div className="flex items-center mt-2">
                          <span className="text-sm text-gray-600">
                            Expires: {dayjs(user.expiryDate).format('MMM D, YYYY')}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg text-gray-800">KSH {user.subscriptionAmount.toLocaleString()}</p>
                        {user.routerCost > 0 && (
                          <p className="text-sm text-gray-600">Router: KSH {user.routerCost.toLocaleString()}</p>
                        )}
                        
                        {/* Action Buttons */}
                        <div className="flex flex-wrap gap-2 mt-3">
                          <button
                            onClick={() => setViewingUser(user)}
                            className="p-2 bg-gradient-to-r from-blue-100 to-blue-200 text-blue-700 rounded-lg hover:from-blue-200 hover:to-blue-300 transition-all duration-200 text-sm shadow-sm"
                            title="View Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleEdit(user)}
                            className="p-2 bg-gradient-to-r from-indigo-100 to-indigo-200 text-indigo-700 rounded-lg hover:from-indigo-200 hover:to-indigo-300 transition-all duration-200 text-sm shadow-sm"
                            title="Edit User"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleRenewSubscription(user._id, user.subscriptionAmount)}
                            className="p-2 bg-gradient-to-r from-green-100 to-emerald-200 text-green-700 rounded-lg hover:from-green-200 hover:to-emerald-300 transition-all duration-200 text-sm shadow-sm"
                            title="Renew Subscription"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleUpgradePackage(user._id)}
                            className="p-2 bg-gradient-to-r from-yellow-100 to-orange-200 text-yellow-700 rounded-lg hover:from-yellow-200 hover:to-orange-300 transition-all duration-200 text-sm shadow-sm"
                            title="Upgrade Package"
                          >
                            <ArrowUp className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(user._id)}
                            className="p-2 bg-gradient-to-r from-red-100 to-pink-200 text-red-700 rounded-lg hover:from-red-200 hover:to-pink-300 transition-all duration-200 text-sm shadow-sm"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    {expandedCard === user._id && (
                      <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p><strong>Payment Date:</strong> {dayjs(user.paymentDate).format('MMM D, YYYY')}</p>
                            <p><strong>Expiry Date:</strong> {dayjs(user.expiryDate).format('MMM D, YYYY')}</p>
                          </div>
                          <div>
                            <p><strong>Days Remaining:</strong> {dayjs(user.expiryDate).diff(dayjs(), 'days')} days</p>
                            <p><strong>Account Status:</strong> {new Date(user.expiryDate) > new Date() ? 'Active' : 'Expired'}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    <button
                      onClick={() => setExpandedCard(expandedCard === user._id ? null : user._id)}
                      className="mt-3 text-indigo-600 hover:text-indigo-800 text-sm font-medium transition-colors duration-200"
                    >
                      {expandedCard === user._id ? 'Show Less' : 'Show More Details'}
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* View User Modal */}
      {viewingUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">User Profile</h2>
                <button
                  onClick={() => setViewingUser(null)}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-800 mb-4">Personal Information</h3>
                  <div className="space-y-3">
                    <p><strong>Name:</strong> {viewingUser.name}</p>
                    <p><strong>Phone:</strong> {viewingUser.phone}</p>
                    <p><strong>Location:</strong> {viewingUser.location}</p>
                    <p><strong>Package:</strong> {viewingUser.package}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-800 mb-4">Subscription Details</h3>
                  <div className="space-y-3">
                    <p><strong>Monthly Amount:</strong> KSH {viewingUser.subscriptionAmount.toLocaleString()}</p>
                    <p><strong>Router Cost:</strong> KSH {(viewingUser.routerCost || 0).toLocaleString()}</p>
                    <p><strong>Payment Date:</strong> {dayjs(viewingUser.paymentDate).format('MMMM D, YYYY')}</p>
                    <p><strong>Expiry Date:</strong> {dayjs(viewingUser.expiryDate).format('MMMM D, YYYY')}</p>
                    <p><strong>Status:</strong> 
                      <span className={`ml-2 px-2 py-1 rounded-full text-sm ${
                        viewingUser.paidSubscription ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}>
                        {viewingUser.paidSubscription ? 'Paid' : 'Unpaid'}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <h3 className="font-semibold text-gray-800 mb-4">Quick Actions</h3>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => {
                      setViewingUser(null);
                      handleRenewSubscription(viewingUser._id, viewingUser.subscriptionAmount);
                    }}
                    className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Renew Subscription</span>
                  </button>
                  <button
                    onClick={() => {
                      setViewingUser(null);
                      handleUpgradePackage(viewingUser._id);
                    }}
                    className="bg-gradient-to-r from-yellow-600 to-orange-600 text-white px-4 py-2 rounded-lg hover:from-yellow-700 hover:to-orange-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                  >
                    <ArrowUp className="w-4 h-4" />
                    <span>Upgrade Package</span>
                  </button>
                  <button
                    onClick={() => {
                      setViewingUser(null);
                      handleEdit(viewingUser);
                    }}
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Edit Details</span>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 px-6 py-4 border-t flex justify-end">
              <button
                onClick={() => setViewingUser(null)}
                className="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageUsers;