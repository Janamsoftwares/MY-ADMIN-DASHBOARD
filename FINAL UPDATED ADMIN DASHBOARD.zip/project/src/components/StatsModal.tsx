import React from 'react';
import { X, TrendingUp, Users, AlertTriangle, DollarSign, Router, Globe } from 'lucide-react';
import dayjs from 'dayjs';
import { User, Booking } from '../types';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: string;
  users: User[];
  bookings: Booking[];
}

const StatsModal: React.FC<StatsModalProps> = ({ isOpen, onClose, type, users, bookings }) => {
  if (!isOpen) return null;

  const getModalContent = () => {
    const now = new Date();
    const activeUsers = users.filter(u => !u.isDeleted && new Date(u.expiryDate) > now);
    const expiredUsers = users.filter(u => !u.isDeleted && new Date(u.expiryDate) <= now);
    const monthlyIncome = activeUsers.reduce((sum, user) => sum + (user.paidSubscription ? user.subscriptionAmount : 0), 0);
    const routerRevenue = users.filter(u => !u.isDeleted).reduce((sum, user) => sum + (user.routerCost || 0), 0);

    switch (type) {
      case 'users':
        return {
          title: 'Total Users Overview',
          icon: <Users className="w-8 h-8 text-indigo-600" />,
          data: users.filter(u => !u.isDeleted),
          stats: [
            { label: 'Total Registered', value: users.filter(u => !u.isDeleted).length, color: 'text-indigo-600' },
            { label: 'Active Subscriptions', value: activeUsers.length, color: 'text-green-600' },
            { label: 'Expired Subscriptions', value: expiredUsers.length, color: 'text-red-600' },
            { label: 'Paid Users', value: users.filter(u => !u.isDeleted && u.paidSubscription).length, color: 'text-blue-600' }
          ]
        };

      case 'active':
        return {
          title: 'Active Users Details',
          icon: <TrendingUp className="w-8 h-8 text-green-600" />,
          data: activeUsers,
          stats: [
            { label: 'Active Users', value: activeUsers.length, color: 'text-green-600' },
            { label: 'Monthly Revenue', value: `KSH ${monthlyIncome.toLocaleString()}`, color: 'text-green-600' },
            { label: 'Average Subscription', value: `KSH ${activeUsers.length > 0 ? Math.round(monthlyIncome / activeUsers.length) : 0}`, color: 'text-blue-600' },
            { label: 'Retention Rate', value: `${activeUsers.length > 0 ? Math.round((activeUsers.length / users.filter(u => !u.isDeleted).length) * 100) : 0}%`, color: 'text-purple-600' }
          ]
        };

      case 'expired':
        return {
          title: 'Expired Users - Action Required',
          icon: <AlertTriangle className="w-8 h-8 text-red-600" />,
          data: expiredUsers,
          stats: [
            { label: 'Expired Users', value: expiredUsers.length, color: 'text-red-600' },
            { label: 'Potential Revenue', value: `KSH ${expiredUsers.reduce((sum, user) => sum + user.subscriptionAmount, 0).toLocaleString()}`, color: 'text-orange-600' },
            { label: 'Average Days Expired', value: Math.round(expiredUsers.reduce((sum, user) => sum + Math.max(0, (now.getTime() - new Date(user.expiryDate).getTime()) / (1000 * 60 * 60 * 24)), 0) / (expiredUsers.length || 1)), color: 'text-red-600' },
            { label: 'Churn Rate', value: `${users.filter(u => !u.isDeleted).length > 0 ? Math.round((expiredUsers.length / users.filter(u => !u.isDeleted).length) * 100) : 0}%`, color: 'text-red-600' }
          ]
        };

      case 'monthly-income':
        return {
          title: `${dayjs().format('MMMM YYYY')} Income Analysis`,
          icon: <DollarSign className="w-8 h-8 text-yellow-600" />,
          data: activeUsers.filter(u => u.paidSubscription),
          stats: [
            { label: 'Monthly Income', value: `KSH ${monthlyIncome.toLocaleString()}`, color: 'text-yellow-600' },
            { label: 'Paid Subscribers', value: users.filter(u => !u.isDeleted && u.paidSubscription).length, color: 'text-green-600' },
            { label: 'Average Revenue Per User', value: `KSH ${activeUsers.length > 0 ? Math.round(monthlyIncome / activeUsers.length) : 0}`, color: 'text-blue-600' },
            { label: 'Projected Annual', value: `KSH ${(monthlyIncome * 12).toLocaleString()}`, color: 'text-purple-600' }
          ]
        };

      case 'router':
        return {
          title: 'Router Sales Revenue',
          icon: <Router className="w-8 h-8 text-pink-600" />,
          data: users.filter(u => !u.isDeleted && u.routerCost > 0),
          stats: [
            { label: 'Total Router Revenue', value: `KSH ${routerRevenue.toLocaleString()}`, color: 'text-pink-600' },
            { label: 'Routers Sold', value: users.filter(u => !u.isDeleted && u.routerCost > 0).length, color: 'text-blue-600' },
            { label: 'Average Router Price', value: `KSH ${users.filter(u => !u.isDeleted && u.routerCost > 0).length > 0 ? Math.round(routerRevenue / users.filter(u => !u.isDeleted && u.routerCost > 0).length) : 0}`, color: 'text-green-600' },
            { label: 'Router Attachment Rate', value: `${users.filter(u => !u.isDeleted).length > 0 ? Math.round((users.filter(u => !u.isDeleted && u.routerCost > 0).length / users.filter(u => !u.isDeleted).length) * 100) : 0}%`, color: 'text-purple-600' }
          ]
        };

      case 'bookings':
        return {
          title: 'Website Bookings & Inquiries',
          icon: <Globe className="w-8 h-8 text-blue-600" />,
          data: bookings,
          stats: [
            { label: 'Total Inquiries', value: bookings.length, color: 'text-blue-600' },
            { label: 'This Month', value: bookings.filter(b => dayjs(b.date).format('YYYY-MM') === dayjs().format('YYYY-MM')).length, color: 'text-green-600' },
            { label: 'This Week', value: bookings.filter(b => dayjs(b.date).isAfter(dayjs().subtract(7, 'days'))).length, color: 'text-purple-600' },
            { label: 'Conversion Rate', value: `${bookings.length > 0 ? Math.round((users.filter(u => !u.isDeleted).length / bookings.length) * 100) : 0}%`, color: 'text-orange-600' }
          ]
        };

      default:
        return { title: '', icon: null, data: [], stats: [] };
    }
  };

  const { title, icon, data, stats } = getModalContent();

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {icon}
              <h2 className="text-2xl font-bold">{title}</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-full transition-colors duration-200"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="p-6 bg-gray-50">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white p-4 rounded-xl shadow-sm border">
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Data Table */}
        <div className="p-6 overflow-y-auto max-h-96">
          {data.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 text-6xl mb-4">📊</div>
              <p className="text-gray-500 text-lg">No data available for this category</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full table-auto">
                <thead>
                  <tr className="bg-gray-100">
                    {type === 'bookings' ? (
                      <>
                        <th className="px-4 py-3 text-left font-semibold">Name</th>
                        <th className="px-4 py-3 text-left font-semibold">Email</th>
                        <th className="px-4 py-3 text-left font-semibold">Phone</th>
                        <th className="px-4 py-3 text-left font-semibold">Location</th>
                        <th className="px-4 py-3 text-left font-semibold">Package</th>
                        <th className="px-4 py-3 text-left font-semibold">Date</th>
                      </>
                    ) : (
                      <>
                        <th className="px-4 py-3 text-left font-semibold">Name</th>
                        <th className="px-4 py-3 text-left font-semibold">Phone</th>
                        <th className="px-4 py-3 text-left font-semibold">Location</th>
                        <th className="px-4 py-3 text-left font-semibold">Package</th>
                        <th className="px-4 py-3 text-left font-semibold">Amount</th>
                        <th className="px-4 py-3 text-left font-semibold">Expiry</th>
                        <th className="px-4 py-3 text-left font-semibold">Status</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {type === 'bookings' ? (
                    bookings.map((booking, index) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3 font-medium">{booking.name}</td>
                        <td className="px-4 py-3">{booking.email}</td>
                        <td className="px-4 py-3">{booking.phone}</td>
                        <td className="px-4 py-3">{booking.location}</td>
                        <td className="px-4 py-3">{booking.package}</td>
                        <td className="px-4 py-3">{dayjs(booking.date).format('MMM D, YYYY')}</td>
                      </tr>
                    ))
                  ) : (
                    data.map((user, index) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3 font-medium">{user.name}</td>
                        <td className="px-4 py-3">{user.phone}</td>
                        <td className="px-4 py-3">{user.location}</td>
                        <td className="px-4 py-3 text-sm">{user.package}</td>
                        <td className="px-4 py-3 font-semibold">KSH {user.subscriptionAmount.toLocaleString()}</td>
                        <td className="px-4 py-3">{dayjs(user.expiryDate).format('MMM D, YYYY')}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            user.paidSubscription 
                              ? 'bg-green-100 text-green-700' 
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {user.paidSubscription ? 'Paid' : 'Unpaid'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-4 border-t">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-600">
              Last updated: {dayjs().format('MMM D, YYYY [at] h:mm A')}
            </p>
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsModal;