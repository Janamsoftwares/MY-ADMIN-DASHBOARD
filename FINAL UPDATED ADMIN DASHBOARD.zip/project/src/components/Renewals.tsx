import React, { useState } from 'react';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';
import { User } from '../types';

interface RenewalsProps {
  users: User[];
  onRenewUser: (userId: string, amount: number) => void;
}

const Renewals: React.FC<RenewalsProps> = ({ users, onRenewUser }) => {
  const [selectedUserId, setSelectedUserId] = useState('');
  const [renewalAmount, setRenewalAmount] = useState('');

  const activeUsers = users.filter(u => !u.isDeleted);
  const now = new Date();
  const fiveDaysFromNow = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);

  const expiringSoon = activeUsers.filter(user => 
    new Date(user.expiryDate) > now && 
    new Date(user.expiryDate) <= fiveDaysFromNow
  );

  const dormantUsers = activeUsers.filter(user => 
    new Date(user.expiryDate) <= now
  );

  // Calculate current month renewals
  const currentMonth = dayjs().format('YYYY-MM');
  const monthlyRenewals = activeUsers.filter(user => 
    user.paidSubscription && 
    user.paymentDate && 
    user.paymentDate.startsWith(currentMonth)
  );

  const renewalsRevenue = monthlyRenewals.reduce((sum, user) => sum + user.subscriptionAmount, 0);

  const processQuickRenewal = () => {
    if (!selectedUserId || !renewalAmount) {
      Swal.fire('Error', 'Please select a user and enter renewal amount', 'error');
      return;
    }

    const user = users.find(u => u._id === selectedUserId);
    if (!user) {
      Swal.fire('Error', 'User not found', 'error');
      return;
    }

    onRenewUser(selectedUserId, parseInt(renewalAmount));
    Swal.fire('Success', `${user.name} renewed successfully!`, 'success');
    
    setRenewalAmount('');
    setSelectedUserId('');
  };

  return (
    <div className="space-y-8">
      <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
        Renewal Management
      </h3>
      
      {/* Quick Renewal Form */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">🔄 Quick User Renewal</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Select User</label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            >
              <option value="">Choose a user...</option>
              {activeUsers.map(user => (
                <option key={user._id} value={user._id}>
                  {user.name} - {user.location}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Renewal Amount (Ksh)</label>
            <input
              type="number"
              value={renewalAmount}
              onChange={(e) => setRenewalAmount(e.target.value)}
              placeholder="Enter amount"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={processQuickRenewal}
              className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-4 rounded-xl hover:from-green-600 hover:to-green-700 transition font-semibold transform hover:-translate-y-1"
            >
              🔄 Renew Now
            </button>
          </div>
        </div>
      </div>

      {/* Expiring Soon and Dormant Users */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Expiring Soon Users */}
        {expiringSoon.length > 0 && (
          <div className="bg-white/80 backdrop-blur-sm border-l-4 border-yellow-400 p-8 rounded-2xl">
            <h4 className="text-lg font-semibold text-yellow-700 mb-6">📅 Users Expiring Soon (Next 5 Days)</h4>
            <div className="space-y-4">
              {expiringSoon.map(user => (
                <div key={user._id} className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold">{user.name}</p>
                      <p className="text-sm text-gray-600">Expires: {dayjs(user.expiryDate).format('MMM D, YYYY')}</p>
                    </div>
                    <span className="text-lg font-bold text-yellow-700">
                      KSH {user.subscriptionAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Dormant Users */}
        {dormantUsers.length > 0 && (
          <div className="bg-white/80 backdrop-blur-sm border-l-4 border-red-400 p-8 rounded-2xl">
            <h4 className="text-lg font-semibold text-red-700 mb-6">👥 Dormant Users</h4>
            <div className="space-y-4">
              {dormantUsers.map(user => (
                <div key={user._id} className="p-4 bg-red-50 rounded-lg border border-red-200">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold">{user.name}</p>
                      <p className="text-sm text-gray-600">Expired: {dayjs(user.expiryDate).format('MMM D, YYYY')}</p>
                    </div>
                    <span className="text-lg font-bold text-red-700">
                      KSH {user.subscriptionAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Current Month Renewals Summary */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">
          💰 {dayjs().format('MMMM')} Renewals Summary
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="text-center p-6 bg-gradient-to-r from-green-50 to-green-100 rounded-xl border border-green-200">
            <p className="text-3xl font-bold text-green-600">{monthlyRenewals.length}</p>
            <p className="text-sm text-gray-600 font-medium">Renewals This Month</p>
          </div>
          <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
            <p className="text-3xl font-bold text-blue-600">Ksh {renewalsRevenue.toLocaleString()}</p>
            <p className="text-sm text-gray-600 font-medium">Total Revenue</p>
          </div>
          <div className="text-center p-6 bg-gradient-to-r from-yellow-50 to-yellow-100 rounded-xl border border-yellow-200">
            <p className="text-3xl font-bold text-yellow-600">
              {monthlyRenewals.length > 0 ? Math.round(renewalsRevenue / monthlyRenewals.length) : 0}
            </p>
            <p className="text-sm text-gray-600 font-medium">Average Per Renewal</p>
          </div>
        </div>
        
        <hr className="my-6 border-gray-200" />
        
        <div>
          <h5 className="font-semibold text-gray-800 mb-4">Recent Renewals</h5>
          <div className="space-y-3">
            {monthlyRenewals.slice(0, 5).map(user => (
              <div key={user._id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-medium">{user.name}</span>
                <span className="text-green-600 font-semibold">
                  KSH {user.subscriptionAmount.toLocaleString()}
                </span>
              </div>
            ))}
            {monthlyRenewals.length === 0 && (
              <p className="text-gray-500 text-center py-4">No renewals this month yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Renewals;