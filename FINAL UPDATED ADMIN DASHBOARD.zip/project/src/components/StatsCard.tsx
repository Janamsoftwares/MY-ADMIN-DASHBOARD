import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle: string;
  icon: string;
  color: string;
  onClick?: () => void;
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  color,
  onClick
}) => {
  return (
    <div
      onClick={onClick}
      className={`relative overflow-hidden bg-gradient-to-br from-white via-gray-50 to-gray-100 backdrop-blur-xl p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 cursor-pointer transform hover:-translate-y-3 hover:scale-105 border border-white/20 group`}
    >
      {/* Animated background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-indigo-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-purple-200/30 to-transparent rounded-full blur-2xl"></div>
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-blue-200/30 to-transparent rounded-full blur-xl"></div>
      
      {/* Accent border */}
      <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${color.replace('border-', 'from-').replace('text-', 'to-')} rounded-r-full`}></div>
      
      {/* Content */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex-1">
          <p className={`font-bold text-lg mb-3 ${color.replace('border-', 'text-')} drop-shadow-sm`}>
            {title}
          </p>
          <p className="text-4xl font-black text-gray-800 mb-2 drop-shadow-sm group-hover:text-gray-900 transition-colors duration-300">
            {value}
          </p>
          <p className="text-sm text-gray-600 font-medium group-hover:text-gray-700 transition-colors duration-300">
            {subtitle}
          </p>
        </div>
        <div className="text-6xl opacity-80 group-hover:opacity-100 transition-all duration-300 transform group-hover:scale-110 drop-shadow-lg">
          {icon}
        </div>
      </div>
      
      {/* Hover effect overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 transform translate-x-[-100%] group-hover:translate-x-[100%] duration-1000"></div>
    </div>
  );
};

export default StatsCard;