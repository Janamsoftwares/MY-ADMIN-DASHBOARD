import React, { useState } from 'react';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';
import { User } from '../types';

interface RegisterUserProps {
  onAddUser: (user: User) => void;
}

const RegisterUser: React.FC<RegisterUserProps> = ({ onAddUser }) => {
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    phone: '',
    subscriptionAmount: '',
    routerCost: '',
    paymentDate: '',
    paidSubscription: false,
    package: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newUser: User = {
      _id: Date.now().toString(),
      name: formData.name,
      phone: formData.phone,
      location: formData.location,
      subscriptionAmount: parseInt(formData.subscriptionAmount),
      routerCost: parseInt(formData.routerCost) || 0,
      paymentDate: formData.paymentDate,
      paidSubscription: formData.paidSubscription,
      package: formData.package,
      expiryDate: dayjs(formData.paymentDate).add(30, 'days').format('YYYY-MM-DD'),
      isDeleted: false
    };

    onAddUser(newUser);
    
    Swal.fire('Success', 'User registered successfully!', 'success');
    
    // Reset form
    setFormData({
      name: '',
      location: '',
      phone: '',
      subscriptionAmount: '',
      routerCost: '',
      paymentDate: '',
      paidSubscription: false,
      package: ''
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const packages = [
    'Bronze Plan - Up to 5 Mbps (Ksh 1,500/Month)',
    'Silver Plan - Up to 10 Mbps (Ksh 2,000/Month)',
    'Gold Plan - Up to 15 Mbps (Ksh 2,500/Month)',
    'Platinum Plan - Up to 20 Mbps (Ksh 3,000/Month)',
    'Super Plan - Up to 35 Mbps (Ksh 4,500/Month)',
    'Dedicated Link - Up to 200 Mbps (Contact for Quote)'
  ];

  return (
    <div className="space-y-8">
      <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
        Register New User
      </h3>
      
      <form onSubmit={handleSubmit} className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
            <input
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter full name"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Location</label>
            <input
              name="location"
              value={formData.location}
              onChange={handleChange}
              placeholder="Enter location"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
            <input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="+254 xxx xxx xxx"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Subscription Amount</label>
            <input
              name="subscriptionAmount"
              type="number"
              value={formData.subscriptionAmount}
              onChange={handleChange}
              placeholder="Enter amount"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Router Cost</label>
            <input
              name="routerCost"
              type="number"
              value={formData.routerCost}
              onChange={handleChange}
              placeholder="0 if none"
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Payment Date</label>
            <input
              name="paymentDate"
              type="date"
              value={formData.paymentDate}
              onChange={handleChange}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
              required
            />
          </div>
        </div>

        <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
          <input
            type="checkbox"
            id="paidSubscription"
            name="paidSubscription"
            checked={formData.paidSubscription}
            onChange={handleChange}
            className="w-5 h-5 text-indigo-600 border-2 border-gray-300 rounded focus:ring-indigo-500"
          />
          <label htmlFor="paidSubscription" className="text-gray-700 font-medium">
            Has the user paid the subscription?
          </label>
        </div>

        <div>
          <label htmlFor="package" className="block text-sm font-semibold text-gray-700 mb-2">
            Select Internet Package
          </label>
          <select
            name="package"
            value={formData.package}
            onChange={handleChange}
            required
            className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 transition-all duration-200"
          >
            <option value="" disabled>Choose a Package</option>
            {packages.map((pkg) => (
              <option key={pkg} value={pkg}>{pkg}</option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-lg font-semibold py-4 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:-translate-y-1 shadow-lg"
        >
          <span className="mr-2">✨</span> Register User
        </button>
      </form>
    </div>
  );
};

export default RegisterUser;