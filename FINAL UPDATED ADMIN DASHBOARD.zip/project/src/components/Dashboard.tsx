import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import dayjs from 'dayjs';
import { User, Booking } from '../types';
import StatsCard from './StatsCard';
import StatsModal from './StatsModal';
import ProfileSection from './ProfileSection';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface DashboardProps {
  users: User[];
  bookings: Booking[];
}

const Dashboard: React.FC<DashboardProps> = ({ users, bookings }) => {
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    type: string;
  }>({
    isOpen: false,
    type: ''
  });

  const calculateStats = () => {
    const now = new Date();
    const activeUsers = users.filter(user => 
      !user.isDeleted && new Date(user.expiryDate) > now
    );
    const expiredUsers = users.filter(user => 
      !user.isDeleted && new Date(user.expiryDate) <= now
    );
    
    const monthlyIncome = activeUsers.reduce((sum, user) => 
      sum + (user.paidSubscription ? user.subscriptionAmount : 0), 0
    );
    
    const routerRevenue = users
      .filter(user => !user.isDeleted)
      .reduce((sum, user) => sum + (user.routerCost || 0), 0);

    return {
      totalUsers: users.filter(u => !u.isDeleted).length,
      activeUsers: activeUsers.length,
      expiredUsers: expiredUsers.length,
      monthlyIncome,
      routerRevenue,
      totalBookings: bookings.length
    };
  };

  const stats = calculateStats();

  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
    datasets: [
      {
        label: 'Monthly Income (Ksh)',
        data: [45000, 52000, 48000, 61000, 55000, 67000, stats.monthlyIncome],
        borderColor: 'rgb(102, 126, 234)',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        tension: 0.4,
        fill: true,
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value: any) {
            return 'Ksh ' + value.toLocaleString();
          }
        }
      }
    }
  };

  const openModal = (type: string) => {
    setModalState({ isOpen: true, type });
  };

  const closeModal = () => {
    setModalState({ isOpen: false, type: '' });
  };

  return (
    <div className="space-y-8">
      {/* Profile Section */}
      <ProfileSection />

      {/* Header */}
      <div className="animate-fade-in-up">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2">
          Network Management Dashboard
        </h1>
        <p className="text-xl text-gray-600">Real-time insights and analytics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <StatsCard
          title="Total Users"
          value={stats.totalUsers}
          subtitle="Registered clients"
          icon="👥"
          color="border-indigo-500 text-indigo-600"
          onClick={() => openModal('users')}
        />
        
        <StatsCard
          title="Active Users"
          value={stats.activeUsers}
          subtitle="Currently subscribed"
          icon="✅"
          color="border-green-500 text-green-600"
          onClick={() => openModal('active')}
        />
        
        <StatsCard
          title="Expired Users"
          value={stats.expiredUsers}
          subtitle="Need renewal"
          icon="⚠️"
          color="border-red-500 text-red-600"
          onClick={() => openModal('expired')}
        />
        
        <StatsCard
          title={`Monthly Income (${dayjs().format('MMMM')})`}
          value={`Ksh ${stats.monthlyIncome.toLocaleString()}`}
          subtitle={`${users.filter(u => u.paidSubscription && !u.isDeleted).length} paid subscribers`}
          icon="💰"
          color="border-yellow-500 text-yellow-600"
          onClick={() => openModal('monthly-income')}
        />
        
        <StatsCard
          title="Router Revenue"
          value={`Ksh ${stats.routerRevenue.toLocaleString()}`}
          subtitle="Hardware sales"
          icon="📡"
          color="border-pink-500 text-pink-600"
          onClick={() => openModal('router')}
        />
        
        <StatsCard
          title="Bookings"
          value={stats.totalBookings}
          subtitle="Website inquiries"
          icon="🌐"
          color="border-blue-500 text-blue-600"
          onClick={() => openModal('bookings')}
        />
      </div>

      {/* Income Chart */}
      <div className="relative overflow-hidden bg-gradient-to-br from-white via-gray-50 to-blue-50 backdrop-blur-xl rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-500 border border-white/20">
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-blue-200/30 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-purple-200/30 to-transparent rounded-full blur-2xl"></div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Income Trend (Monthly)
            </h3>
            <div className="flex space-x-2">
              <span className="px-4 py-2 bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 rounded-full text-sm font-medium shadow-sm">
                📈 Growing
              </span>
            </div>
          </div>
          <Line data={chartData} options={chartOptions} height={120} />
        </div>
      </div>

      {/* Stats Modal */}
      <StatsModal
        isOpen={modalState.isOpen}
        onClose={closeModal}
        type={modalState.type}
        users={users}
        bookings={bookings}
      />
    </div>
  );
};

export default Dashboard;
