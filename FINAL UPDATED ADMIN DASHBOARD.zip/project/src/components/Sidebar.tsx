import React from 'react';
import { User, Settings } from 'lucide-react';

interface SidebarProps {
  currentSection: string;
  onNavigate: (section: string) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentSection, onNavigate, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', icon: '📊', label: 'Dashboard' },
    { id: 'register-user', icon: '➕', label: 'Register User' },
    { id: 'manage-users', icon: '👥', label: 'Manage Users' },
    { id: 'renewals', icon: '🔄', label: 'Renewals' },
    { id: 'invoice-generator', icon: '🧾', label: 'Invoice Generator' },
    { id: 'website-bookings', icon: '🌐', label: 'Website Bookings' },
    { id: 'settings', icon: <Settings className="w-6 h-6" />, label: 'Settings' }
  ];

  return (
    <aside className="w-72 h-screen bg-gradient-to-b from-blue-900 via-purple-800 to-gray-700 shadow-2xl flex flex-col text-white relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -translate-y-16 translate-x-16"></div>
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white opacity-5 rounded-full translate-y-12 -translate-x-12"></div>
      
      <div className="p-6 border-b border-white/20 backdrop-blur-sm bg-white/10">
        <h2 className="text-3xl font-extrabold tracking-wide mb-2">Dr.Net Admin</h2>
        <p className="text-sm text-gray-200 mt-1 flex items-center">
          <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
          Julius - CTO
        </p>
      </div>
      
      <nav className="p-4 space-y-3 flex-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full text-left py-4 px-6 rounded-xl transition-all duration-300 ${
              currentSection === item.id
                ? 'bg-white/20 shadow-lg backdrop-blur-sm border border-white/10'
                : 'hover:bg-white/20 backdrop-blur-sm'
            } transform hover:-translate-y-1 hover:shadow-lg`}
          >
            <span className="text-2xl mr-4">
              {typeof item.icon === 'string' ? item.icon : item.icon}
            </span>
            <span className="font-medium text-lg">{item.label}</span>
          </button>
        ))}
      </nav>
      
      <div className="p-4 border-t border-white/20">
        <button
          onClick={onLogout}
          className="w-full bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-3 rounded-xl hover:from-red-600 hover:to-pink-700 transition-all duration-300 font-semibold shadow-lg transform hover:-translate-y-1"
        >
          <span className="mr-2">🚪</span> Log Out
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;