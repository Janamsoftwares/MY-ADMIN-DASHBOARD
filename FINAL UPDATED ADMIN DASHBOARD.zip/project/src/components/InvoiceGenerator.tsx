import React, { useState } from 'react';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';
import jsPDF from 'jspdf';
import { User } from '../types';

interface InvoiceGeneratorProps {
  users: User[];
}

const InvoiceGenerator: React.FC<InvoiceGeneratorProps> = ({ users }) => {
  const [selectedUserId, setSelectedUserId] = useState('');
  const [currentSMSContent, setCurrentSMSContent] = useState('');
  const [showInvoicePreview, setShowInvoicePreview] = useState(false);
  const [showSMSPreview, setShowSMSPreview] = useState(false);
  const [invoiceData, setInvoiceData] = useState<any>(null);

  const activeUsers = users.filter(u => !u.isDeleted);

  const generateInvoice = () => {
    if (!selectedUserId) {
      Swal.fire('Error', 'Please select a user first', 'error');
      return;
    }

    const user = users.find(u => u._id === selectedUserId);
    if (!user) {
      Swal.fire('Error', 'User not found', 'error');
      return;
    }

    const invoice = {
      id: 'INV-' + Date.now(),
      userId: user._id,
      userName: user.name,
      userPhone: user.phone,
      userLocation: user.location,
      amount: user.subscriptionAmount,
      invoiceNumber: 'INV-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
      issueDate: dayjs().format('YYYY-MM-DD'),
      dueDate: dayjs().add(7, 'days').format('YYYY-MM-DD'),
      status: 'pending'
    };

    generateInvoicePDF(invoice);
    setInvoiceData(invoice);
    setShowInvoicePreview(true);
  };

  const generateInvoicePDF = (invoice: any) => {
    const pdf = new jsPDF();
    
    // Company branding
    pdf.setFontSize(24);
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(220, 38, 127);
    pdf.text('DR.NET TECHNOLOGY LABS', 20, 30);
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100, 100, 100);
    pdf.text('Internet Service Provider & Technology Solutions', 20, 38);
    pdf.text('Phone: 0701782354 | Email: dr.netinnovations@gmail.com', 20, 45);
    pdf.text('Website: www.drnet.co.ke', 20, 52);
    
    // Invoice header
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(0, 0, 0);
    pdf.text('INVOICE', 150, 30);
    
    // Invoice details box
    pdf.setDrawColor(220, 38, 127);
    pdf.setLineWidth(0.5);
    pdf.rect(120, 35, 70, 25);
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Invoice #: ${invoice.invoiceNumber}`, 125, 42);
    pdf.text(`Issue Date: ${dayjs(invoice.issueDate).format('MMM D, YYYY')}`, 125, 48);
    pdf.text(`Due Date: ${dayjs(invoice.dueDate).format('MMM D, YYYY')}`, 125, 54);
    
    // Client information
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('BILL TO:', 20, 80);
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    pdf.text(invoice.userName, 20, 90);
    pdf.text(`Phone: ${invoice.userPhone}`, 20, 98);
    pdf.text(`Location: ${invoice.userLocation}`, 20, 106);
    
    // Service details table
    const startY = 130;
    
    // Table header
    pdf.setFillColor(240, 240, 240);
    pdf.rect(20, startY, 170, 10, 'F');
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'bold');
    pdf.text('DESCRIPTION', 25, startY + 7);
    pdf.text('PERIOD', 100, startY + 7);
    pdf.text('AMOUNT (KSH)', 140, startY + 7);
    
    // Table content
    pdf.setFont('helvetica', 'normal');
    const contentY = startY + 20;
    pdf.text('Internet Subscription Service', 25, contentY);
    pdf.text('Monthly Service', 100, contentY);
    pdf.text(invoice.amount.toLocaleString(), 145, contentY);
    
    // Subtotal and total
    const totalY = contentY + 30;
    pdf.setDrawColor(0, 0, 0);
    pdf.line(120, totalY - 5, 190, totalY - 5);
    
    pdf.setFont('helvetica', 'bold');
    pdf.text('SUBTOTAL:', 120, totalY);
    pdf.text(`KSH ${invoice.amount.toLocaleString()}`, 160, totalY);
    
    pdf.text('TOTAL DUE:', 120, totalY + 10);
    pdf.setFontSize(12);
    pdf.setTextColor(220, 38, 127);
    pdf.text(`KSH ${invoice.amount.toLocaleString()}`, 160, totalY + 10);
    
    // Payment instructions
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(0, 0, 0);
    pdf.text('PAYMENT INSTRUCTIONS:', 20, totalY + 30);
    pdf.text('• M-PESA: Lipa na M-Pesa Buy Goods', 20, totalY + 38);
    pdf.text('• Till Number: 5626320', 20, totalY + 45);
    pdf.text('• Name: DR.NET TECHNOLOGY LABS', 20, totalY + 52);
    pdf.text(`• Reference: ${invoice.invoiceNumber}`, 20, totalY + 59);
    pdf.text('• Payment due within 7 days of invoice date', 20, totalY + 66);
    pdf.text('• For assistance call: 0701782354', 20, totalY + 73);
    
    // Footer
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text('Thank you for choosing DR.NET TECHNOLOGY LABS!', 20, 270);
    pdf.text('For support: dr.netinnovations@gmail.com or 0701782354', 20, 277);
    
    pdf.save(`DR-NET-Invoice-${invoice.invoiceNumber}.pdf`);
    Swal.fire('Success', 'Invoice PDF generated successfully!', 'success');
  };

  const generateSMSTemplate = (type: string) => {
    if (!selectedUserId) {
      Swal.fire('Error', 'Please select a user first', 'error');
      return;
    }

    const user = users.find(u => u._id === selectedUserId);
    if (!user) {
      Swal.fire('Error', 'User not found', 'error');
      return;
    }

    const invoiceNumber = 'INV-' + Math.random().toString(36).substr(2, 9).toUpperCase();
    const dueDate = dayjs().add(7, 'days').format('MMM D, YYYY');

    let smsContent = '';
    
    switch(type) {
      case 'invoice':
        smsContent = `Dear ${user.name},

Your DR.NET internet subscription has expired. 

Invoice #${invoiceNumber}
Amount Due: KSH ${user.subscriptionAmount.toLocaleString()}
Due Date: ${dueDate}

Please renew to continue enjoying our high-speed internet service.

Payment via M-PESA:
• Lipa na M-Pesa Buy Goods
• Till Number: 5626320
• Name: DR.NET TECHNOLOGY LABS
• Reference: ${invoiceNumber}

Contact us: 0701782354
DR.NET TECHNOLOGY LABS`;
        break;
      case 'reminder':
        smsContent = `REMINDER: ${user.name}

Your DR.NET subscription payment is overdue.

Invoice #${invoiceNumber}
Amount: KSH ${user.subscriptionAmount.toLocaleString()}

Please pay immediately to avoid service suspension.

Pay via M-PESA:
• Lipa na M-Pesa Buy Goods
• Till Number: 5626320
• Reference: ${invoiceNumber}

DR.NET TECHNOLOGY LABS`;
        break;
      case 'confirmation':
        smsContent = `Payment Confirmed! 

Thank you ${user.name}!

Invoice #${invoiceNumber} - PAID
Amount: KSH ${user.subscriptionAmount.toLocaleString()}

Your DR.NET internet service has been renewed for 30 days.

Questions? Call 0701782354
DR.NET TECHNOLOGY LABS`;
        break;
    }

    setCurrentSMSContent(smsContent);
    setShowSMSPreview(true);
  };

  const copySMSToClipboard = () => {
    navigator.clipboard.writeText(currentSMSContent).then(() => {
      Swal.fire('Copied!', 'SMS content copied to clipboard', 'success');
    });
  };

  return (
    <div className="space-y-8">
      <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
        Invoice Generator
      </h3>
      
      {/* User Selection and Invoice Generation */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">Generate Invoice</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Select User</label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
            >
              <option value="">Choose a user...</option>
              {activeUsers.map(user => (
                <option key={user._id} value={user._id}>
                  {user.name} - {user.location}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={generateInvoice}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-xl font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:-translate-y-1"
            >
              <span className="mr-2">🧾</span> Generate Invoice PDF
            </button>
          </div>
        </div>
        
        {/* Invoice Preview */}
        {showInvoicePreview && invoiceData && (
          <div className="mt-6 p-6 bg-gray-50 rounded-xl">
            <h5 className="font-semibold text-gray-800 mb-4">Invoice Preview</h5>
            <div className="border rounded-lg p-4 bg-white">
              <div className="flex justify-between mb-4">
                <div>
                  <h6 className="font-bold text-lg text-pink-600">DR.NET TECHNOLOGY LABS</h6>
                  <p className="text-sm text-gray-600">Internet Service Provider</p>
                </div>
                <div className="text-right">
                  <h6 className="font-bold">INVOICE</h6>
                  <p className="text-sm">#{invoiceData.invoiceNumber}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="font-semibold">Bill To:</p>
                  <p>{invoiceData.userName}</p>
                  <p>{invoiceData.userPhone}</p>
                  <p>{invoiceData.userLocation}</p>
                </div>
                <div className="text-right">
                  <p><strong>Issue Date:</strong> {dayjs(invoiceData.issueDate).format('MMM D, YYYY')}</p>
                  <p><strong>Due Date:</strong> {dayjs(invoiceData.dueDate).format('MMM D, YYYY')}</p>
                  <p><strong>Amount:</strong> KSH {invoiceData.amount.toLocaleString()}</p>
                </div>
              </div>
              <div className="border-t pt-4">
                <h6 className="font-semibold mb-2">Payment Instructions:</h6>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• M-PESA: Lipa na M-Pesa Buy Goods</li>
                  <li>• Till Number: 5626320</li>
                  <li>• Name: DR.NET TECHNOLOGY LABS</li>
                  <li>• Reference: {invoiceData.invoiceNumber}</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SMS Templates */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">SMS Templates</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => generateSMSTemplate('invoice')}
            className="p-6 bg-blue-50 rounded-xl border-2 border-blue-200 hover:border-blue-400 transition-all duration-200 transform hover:-translate-y-1"
          >
            <div className="text-3xl mb-2">📧</div>
            <div className="font-semibold text-blue-800">Invoice SMS</div>
            <div className="text-sm text-blue-600">Send invoice notification</div>
          </button>
          
          <button
            onClick={() => generateSMSTemplate('reminder')}
            className="p-6 bg-yellow-50 rounded-xl border-2 border-yellow-200 hover:border-yellow-400 transition-all duration-200 transform hover:-translate-y-1"
          >
            <div className="text-3xl mb-2">⏰</div>
            <div className="font-semibold text-yellow-800">Reminder SMS</div>
            <div className="text-sm text-yellow-600">Send payment reminder</div>
          </button>
          
          <button
            onClick={() => generateSMSTemplate('confirmation')}
            className="p-6 bg-green-50 rounded-xl border-2 border-green-200 hover:border-green-400 transition-all duration-200 transform hover:-translate-y-1"
          >
            <div className="text-3xl mb-2">✅</div>
            <div className="font-semibold text-green-800">Payment Confirmation</div>
            <div className="text-sm text-green-600">Confirm payment received</div>
          </button>
        </div>
        
        {/* SMS Preview */}
        {showSMSPreview && (
          <div className="mt-6 p-6 bg-gray-50 rounded-xl">
            <h5 className="font-semibold text-gray-800 mb-4">SMS Preview</h5>
            <div className="bg-white p-4 rounded-lg border font-mono text-sm whitespace-pre-wrap">
              {currentSMSContent}
            </div>
            <button
              onClick={copySMSToClipboard}
              className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition transform hover:-translate-y-1"
            >
              📋 Copy to Clipboard
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default InvoiceGenerator;