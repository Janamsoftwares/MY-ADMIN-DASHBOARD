import React, { useState } from 'react';
import dayjs from 'dayjs';
import Swal from 'sweetalert2';
import { Edit, Trash2, Check, RefreshCw, Eye, Plus, Calendar, Clock } from 'lucide-react';
import { Booking } from '../types';

interface WebsiteBookingsProps {
  bookings: Booking[];
  onRefreshBookings: () => void;
  onUpdateBooking?: (bookingId: string, updates: Partial<Booking>) => void;
  onDeleteBooking?: (bookingId: string) => void;
  onAddBooking?: (booking: Booking) => void;
}

interface BookingWithStatus extends Booking {
  status?: 'pending' | 'processed' | 'contacted';
  installationDate?: string;
  preferredTime?: string;
}

const WebsiteBookings: React.FC<WebsiteBookingsProps> = ({ 
  bookings, 
  onRefreshBookings,
  onUpdateBooking,
  onDeleteBooking,
  onAddBooking 
}) => {
  const [editingBooking, setEditingBooking] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<BookingWithStatus>>({});
  const [viewingBooking, setViewingBooking] = useState<BookingWithStatus | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newBookingForm, setNewBookingForm] = useState<Partial<BookingWithStatus>>({
    status: 'pending',
    date: dayjs().format('YYYY-MM-DD')
  });
  const [bookingsWithStatus, setBookingsWithStatus] = useState<BookingWithStatus[]>(
    bookings.map(booking => ({
      ...booking,
      status: (booking as any).status || 'pending',
      installationDate: (booking as any).installationDate || '',
      preferredTime: (booking as any).preferredTime || ''
    }))
  );

  const handleRefresh = () => {
    onRefreshBookings();
    Swal.fire('Refreshed', 'Bookings have been refreshed', 'success');
  };

  const handleEdit = (booking: BookingWithStatus) => {
    setEditingBooking(booking.id);
    setEditForm(booking);
  };

  const handleSaveEdit = () => {
    if (!editingBooking) return;

    const updatedBookings = bookingsWithStatus.map(booking =>
      booking.id === editingBooking ? { ...booking, ...editForm } : booking
    );
    
    setBookingsWithStatus(updatedBookings);
    setEditingBooking(null);
    setEditForm({});
    
    onUpdateBooking?.(editingBooking, editForm);
    
    Swal.fire({
      title: 'Success!',
      text: 'Booking updated successfully!',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const handleCancelEdit = () => {
    setEditingBooking(null);
    setEditForm({});
  };

  const handleDelete = (bookingId: string) => {
    const booking = bookingsWithStatus.find(b => b.id === bookingId);
    if (!booking) return;

    Swal.fire({
      title: 'Delete Booking?',
      text: `Are you sure you want to delete the booking from ${booking.name}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    }).then((result) => {
      if (result.isConfirmed) {
        const updatedBookings = bookingsWithStatus.filter(b => b.id !== bookingId);
        setBookingsWithStatus(updatedBookings);
        onDeleteBooking?.(bookingId);
        Swal.fire({
          title: 'Deleted!',
          text: 'Booking has been deleted.',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white'
        });
      }
    });
  };

  const handleStatusChange = (bookingId: string, newStatus: 'pending' | 'processed' | 'contacted') => {
    const updatedBookings = bookingsWithStatus.map(booking =>
      booking.id === bookingId ? { ...booking, status: newStatus } : booking
    );
    
    setBookingsWithStatus(updatedBookings);
    onUpdateBooking?.(bookingId, { status: newStatus });
    
    const statusMessages = {
      pending: 'Booking marked as pending',
      processed: 'Booking marked as processed',
      contacted: 'Booking marked as contacted'
    };
    
    Swal.fire({
      title: 'Updated!',
      text: statusMessages[newStatus],
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const handleAddBooking = () => {
    if (!newBookingForm.name || !newBookingForm.phone || !newBookingForm.location || !newBookingForm.package) {
      Swal.fire('Error', 'Please fill in all required fields', 'error');
      return;
    }

    const newBooking: BookingWithStatus = {
      id: 'booking_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
      name: newBookingForm.name!,
      email: newBookingForm.email || '',
      phone: newBookingForm.phone!,
      location: newBookingForm.location!,
      package: newBookingForm.package!,
      message: newBookingForm.message || 'Manually added booking',
      date: newBookingForm.date!,
      status: newBookingForm.status || 'pending',
      installationDate: newBookingForm.installationDate || '',
      preferredTime: newBookingForm.preferredTime || ''
    };

    const updatedBookings = [...bookingsWithStatus, newBooking];
    setBookingsWithStatus(updatedBookings);
    onAddBooking?.(newBooking);
    
    setShowAddModal(false);
    setNewBookingForm({
      status: 'pending',
      date: dayjs().format('YYYY-MM-DD')
    });

    Swal.fire({
      title: 'Success!',
      text: 'New booking added successfully!',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'processed':
        return 'bg-green-100 text-green-700';
      case 'contacted':
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-yellow-100 text-yellow-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processed':
        return '✅';
      case 'contacted':
        return '📞';
      default:
        return '⏳';
    }
  };

  const packages = [
    'Bronze Plan - Up to 5 Mbps (Ksh 1,500/Month)',
    'Silver Plan - Up to 10 Mbps (Ksh 2,000/Month)',
    'Gold Plan - Up to 15 Mbps (Ksh 2,500/Month)',
    'Platinum Plan - Up to 20 Mbps (Ksh 3,000/Month)',
    'Super Plan - Up to 35 Mbps (Ksh 4,500/Month)',
    'Dedicated Link - Up to 200 Mbps (Contact for Quote)'
  ];

  const timeSlots = [
    '8:00 AM - 10:00 AM',
    '10:00 AM - 12:00 PM',
    '12:00 PM - 2:00 PM',
    '2:00 PM - 4:00 PM',
    '4:00 PM - 6:00 PM'
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Website Bookings
        </h3>
        <div className="flex space-x-4">
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all duration-300 font-semibold shadow-lg transform hover:-translate-y-1 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Booking</span>
          </button>
          <button
            onClick={handleRefresh}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg transform hover:-translate-y-1 flex items-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Refresh Bookings</span>
          </button>
        </div>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 font-semibold">Total Bookings</p>
              <p className="text-2xl font-bold">{bookingsWithStatus.length}</p>
            </div>
            <span className="text-3xl">📊</span>
          </div>
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-600 font-semibold">Pending</p>
              <p className="text-2xl font-bold">{bookingsWithStatus.filter(b => b.status === 'pending').length}</p>
            </div>
            <span className="text-3xl">⏳</span>
          </div>
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 font-semibold">Contacted</p>
              <p className="text-2xl font-bold">{bookingsWithStatus.filter(b => b.status === 'contacted').length}</p>
            </div>
            <span className="text-3xl">📞</span>
          </div>
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border-l-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 font-semibold">Processed</p>
              <p className="text-2xl font-bold">{bookingsWithStatus.filter(b => b.status === 'processed').length}</p>
            </div>
            <span className="text-3xl">✅</span>
          </div>
        </div>
      </div>
      
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
        <h4 className="text-xl font-semibold text-gray-800 mb-6">Customer Inquiries</h4>
        <div className="space-y-6">
          {bookingsWithStatus.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 text-6xl mb-4">📋</div>
              <p className="text-gray-500 text-lg">No bookings received yet.</p>
            </div>
          ) : (
            bookingsWithStatus.map(booking => (
              <div key={booking.id} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 border">
                {editingBooking === booking.id ? (
                  // Edit Mode
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                        <input
                          type="text"
                          value={editForm.name || ''}
                          onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input
                          type="email"
                          value={editForm.email || ''}
                          onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <input
                          type="text"
                          value={editForm.phone || ''}
                          onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                        <input
                          type="text"
                          value={editForm.location || ''}
                          onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Package</label>
                        <select
                          value={editForm.package || ''}
                          onChange={(e) => setEditForm({ ...editForm, package: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          {packages.map(pkg => (
                            <option key={pkg} value={pkg}>{pkg}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select
                          value={editForm.status || 'pending'}
                          onChange={(e) => setEditForm({ ...editForm, status: e.target.value as any })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="pending">Pending</option>
                          <option value="contacted">Contacted</option>
                          <option value="processed">Processed</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Installation Date</label>
                        <input
                          type="date"
                          value={editForm.installationDate || ''}
                          onChange={(e) => setEditForm({ ...editForm, installationDate: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Time</label>
                        <select
                          value={editForm.preferredTime || ''}
                          onChange={(e) => setEditForm({ ...editForm, preferredTime: e.target.value })}
                          className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="">Select time slot</option>
                          {timeSlots.map(slot => (
                            <option key={slot} value={slot}>{slot}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                      <textarea
                        value={editForm.message || ''}
                        onChange={(e) => setEditForm({ ...editForm, message: e.target.value })}
                        rows={3}
                        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="flex space-x-3">
                      <button
                        onClick={handleSaveEdit}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition flex items-center space-x-2"
                      >
                        <Check className="w-4 h-4" />
                        <span>Save</span>
                      </button>
                      <button
                        onClick={handleCancelEdit}
                        className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  // View Mode
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h5 className="font-semibold text-lg">{booking.name}</h5>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(booking.status || 'pending')}`}>
                          {getStatusIcon(booking.status || 'pending')} {booking.status || 'pending'}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-gray-600"><strong>Email:</strong> {booking.email}</p>
                          <p className="text-gray-600"><strong>Phone:</strong> {booking.phone}</p>
                        </div>
                        <div>
                          <p className="text-gray-600"><strong>Location:</strong> {booking.location}</p>
                          <p className="text-gray-600"><strong>Package:</strong> {booking.package}</p>
                        </div>
                      </div>
                      {(booking.installationDate || booking.preferredTime) && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          {booking.installationDate && (
                            <div className="flex items-center space-x-2">
                              <Calendar className="w-4 h-4 text-blue-600" />
                              <span className="text-sm text-gray-600">
                                <strong>Installation:</strong> {dayjs(booking.installationDate).format('MMM D, YYYY')}
                              </span>
                            </div>
                          )}
                          {booking.preferredTime && (
                            <div className="flex items-center space-x-2">
                              <Clock className="w-4 h-4 text-green-600" />
                              <span className="text-sm text-gray-600">
                                <strong>Time:</strong> {booking.preferredTime}
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                      <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-lg">
                        <strong>Message:</strong> {booking.message}
                      </p>
                    </div>
                    <div className="flex flex-col items-end space-y-3 ml-6">
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                        {dayjs(booking.date).format('MMM D, YYYY')}
                      </span>
                      
                      {/* Status Change Buttons */}
                      <div className="flex flex-col space-y-2">
                        <select
                          value={booking.status || 'pending'}
                          onChange={(e) => handleStatusChange(booking.id, e.target.value as any)}
                          className="text-sm border rounded-lg px-3 py-1 focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="pending">Pending</option>
                          <option value="contacted">Contacted</option>
                          <option value="processed">Processed</option>
                        </select>
                      </div>
                      
                      {/* Action Buttons */}
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setViewingBooking(booking)}
                          className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(booking)}
                          className="p-2 bg-indigo-100 text-indigo-600 rounded-lg hover:bg-indigo-200 transition"
                          title="Edit"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(booking.id)}
                          className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add Booking Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold flex items-center space-x-2">
                  <Plus className="w-6 h-6" />
                  <span>Add New Booking</span>
                </h2>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors duration-200"
                >
                  <span className="text-2xl">&times;</span>
                </button>
              </div>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                  <input
                    type="text"
                    value={newBookingForm.name || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, name: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                    placeholder="Enter full name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    value={newBookingForm.phone || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, phone: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                    placeholder="+254 xxx xxx xxx"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    value={newBookingForm.email || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, email: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                    placeholder="email@example.com"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location *</label>
                  <input
                    type="text"
                    value={newBookingForm.location || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, location: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                    placeholder="Enter location"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Package *</label>
                  <select
                    value={newBookingForm.package || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, package: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select package</option>
                    {packages.map(pkg => (
                      <option key={pkg} value={pkg}>{pkg}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <select
                    value={newBookingForm.status || 'pending'}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, status: e.target.value as any })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="pending">Pending</option>
                    <option value="contacted">Contacted</option>
                    <option value="processed">Processed</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Installation Date</label>
                  <input
                    type="date"
                    value={newBookingForm.installationDate || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, installationDate: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Time</label>
                  <select
                    value={newBookingForm.preferredTime || ''}
                    onChange={(e) => setNewBookingForm({ ...newBookingForm, preferredTime: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select time slot</option>
                    {timeSlots.map(slot => (
                      <option key={slot} value={slot}>{slot}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                <textarea
                  value={newBookingForm.message || ''}
                  onChange={(e) => setNewBookingForm({ ...newBookingForm, message: e.target.value })}
                  rows={3}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500"
                  placeholder="Additional notes or requirements"
                />
              </div>
            </div>
            
            <div className="bg-gray-50 px-6 py-4 border-t flex justify-end space-x-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-6 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all duration-200"
              >
                Cancel
              </button>
              <button
                onClick={handleAddBooking}
                className="px-6 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200"
              >
                Add Booking
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Booking Modal */}
      {viewingBooking && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Booking Details</h2>
                <button
                  onClick={() => setViewingBooking(null)}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors duration-200"
                >
                  <span className="text-2xl">&times;</span>
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-800 mb-4">Contact Information</h3>
                  <div className="space-y-3">
                    <p><strong>Name:</strong> {viewingBooking.name}</p>
                    <p><strong>Email:</strong> {viewingBooking.email}</p>
                    <p><strong>Phone:</strong> {viewingBooking.phone}</p>
                    <p><strong>Location:</strong> {viewingBooking.location}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-800 mb-4">Booking Information</h3>
                  <div className="space-y-3">
                    <p><strong>Package:</strong> {viewingBooking.package}</p>
                    <p><strong>Date:</strong> {dayjs(viewingBooking.date).format('MMMM D, YYYY')}</p>
                    <p><strong>Status:</strong> 
                      <span className={`ml-2 px-2 py-1 rounded-full text-sm ${getStatusColor(viewingBooking.status || 'pending')}`}>
                        {viewingBooking.status || 'pending'}
                      </span>
                    </p>
                    {viewingBooking.installationDate && (
                      <p><strong>Installation Date:</strong> {dayjs(viewingBooking.installationDate).format('MMMM D, YYYY')}</p>
                    )}
                    {viewingBooking.preferredTime && (
                      <p><strong>Preferred Time:</strong> {viewingBooking.preferredTime}</p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <h3 className="font-semibold text-gray-800 mb-2">Message</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-gray-700">{viewingBooking.message}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 px-6 py-4 border-t flex justify-end">
              <button
                onClick={() => setViewingBooking(null)}
                className="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WebsiteBookings;