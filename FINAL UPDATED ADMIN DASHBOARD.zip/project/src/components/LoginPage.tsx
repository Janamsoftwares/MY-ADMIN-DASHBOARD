import React, { useState } from 'react';
import Swal from 'sweetalert2';

interface LoginPageProps {
  onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // TODO: Change these credentials before deployment
    // Replace 'admin' with your desired username
    // Replace 'drnet2025' with your desired password
    const ADMIN_USERNAME = 'admin';
    const ADMIN_PASSWORD = 'drnet2025';
    
    if (username.trim() === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      localStorage.setItem('adminLoggedIn', 'true');
      Swal.fire({
        title: 'Welcome!',
        text: 'Login successful',
        icon: 'success',
        timer: 1500,
        showConfirmButton: false
      });
      onLogin();
    } else {
      setError(true);
      setTimeout(() => setError(false), 3000);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-pink-200 via-purple-200 to-indigo-200">
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-sm transform hover:scale-105 transition-transform duration-300">
        <h2 className="text-3xl font-bold text-center text-indigo-700 mb-6">🔐 Admin Login</h2>
        
        <div className="mb-4">
          <label htmlFor="username" className="block text-sm font-semibold text-gray-700 mb-1">
            Username
          </label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Enter username"
            required
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all duration-200"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="block text-sm font-semibold text-gray-700 mb-1">
            Password
          </label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            required
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all duration-200"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 rounded-lg font-bold hover:bg-indigo-700 transition duration-200 transform hover:-translate-y-1"
        >
          Log In
        </button>

        {error && (
          <p className="text-red-500 text-sm mt-4 text-center animate-pulse">
            ❌ Invalid credentials. Try again.
          </p>
        )}
      </form>
    </div>
  );
};

export default LoginPage;