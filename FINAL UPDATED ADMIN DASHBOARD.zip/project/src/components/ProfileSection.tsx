import React from 'react';
import { User } from 'lucide-react';

interface ProfileSectionProps {
  onProfileUpdate?: (profileData: any) => void;
}

const ProfileSection: React.FC<ProfileSectionProps> = ({ onProfileUpdate }) => {
  const profileImage = localStorage.getItem('adminProfileImage');
  const adminName = localStorage.getItem('adminName') || 'Julius Kamau';
  const adminTitle = localStorage.getItem('adminTitle') || 'Chief Technology Officer';

  return (
    <div className="relative overflow-hidden rounded-3xl shadow-2xl mb-8">
      {/* Animated Background with Multiple Gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        {/* Animated gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 via-purple-500/30 to-blue-500/20 animate-pulse"></div>
        
        {/* Floating orbs */}
        <div className="absolute top-0 left-0 w-72 h-72 bg-gradient-to-br from-purple-400/30 to-pink-400/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-blue-400/20 to-cyan-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-80 h-80 bg-gradient-to-t from-indigo-400/25 to-purple-400/25 rounded-full blur-3xl animate-pulse delay-500"></div>
        
        {/* Geometric patterns */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-20 h-20 border border-white/20 rotate-45 animate-spin-slow"></div>
          <div className="absolute top-20 right-20 w-16 h-16 border border-white/15 rotate-12 animate-bounce-slow"></div>
          <div className="absolute bottom-20 left-20 w-24 h-24 border border-white/10 -rotate-12 animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-12 h-12 bg-white/5 rounded-full animate-ping"></div>
        </div>
        
        {/* Mesh gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent"></div>
      </div>

      {/* Glass morphism effect */}
      <div className="relative backdrop-blur-xl bg-white/10 border border-white/20 p-8">
        {/* Content */}
        <div className="relative z-10 flex items-center space-x-8">
          {/* Enhanced Profile Picture with Multiple Rings */}
          <div className="relative">
            {/* Outer glow ring */}
            <div className="absolute -inset-4 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 rounded-full blur-lg opacity-75 animate-pulse"></div>
            
            {/* Middle ring */}
            <div className="absolute -inset-2 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 rounded-full opacity-50 animate-spin-slow"></div>
            
            {/* Inner ring */}
            <div className="absolute -inset-1 bg-gradient-to-r from-white/30 to-white/10 rounded-full"></div>
            
            {/* Profile picture container */}
            <div className="relative w-24 h-24 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 via-pink-500 to-blue-600 flex items-center justify-center shadow-2xl border-4 border-white/30">
              {profileImage ? (
                <img 
                  src={profileImage} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-12 h-12 text-white drop-shadow-lg" />
              )}
            </div>
            
            {/* Floating particles around avatar */}
            <div className="absolute -top-2 -right-2 w-3 h-3 bg-yellow-400 rounded-full animate-bounce opacity-80"></div>
            <div className="absolute -bottom-2 -left-2 w-2 h-2 bg-pink-400 rounded-full animate-ping opacity-60"></div>
            <div className="absolute top-1/2 -right-4 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse opacity-70"></div>
          </div>

          {/* Enhanced Profile Info */}
          <div className="flex-1">
            {/* Name with enhanced gradient */}
            <h2 className="text-3xl font-bold bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent drop-shadow-lg mb-1">
              {adminName}
            </h2>
            
            {/* Title with subtle glow */}
            <p className="text-blue-100/90 text-lg font-medium drop-shadow-md mb-3">
              {adminTitle}
            </p>
            
            {/* Enhanced online status */}
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <span className="w-3 h-3 bg-green-400 rounded-full block animate-pulse shadow-lg"></span>
                  <span className="absolute inset-0 w-3 h-3 bg-green-400 rounded-full animate-ping opacity-75"></span>
                </div>
                <span className="text-green-100 text-sm font-medium drop-shadow-sm">Online</span>
              </div>
              
              {/* Additional status indicators */}
              <div className="flex items-center space-x-1">
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse opacity-80"></div>
                <div className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse delay-200 opacity-80"></div>
                <div className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-pulse delay-400 opacity-80"></div>
              </div>
            </div>
          </div>

          {/* Floating action indicators */}
          <div className="hidden lg:flex flex-col space-y-2 opacity-60">
            <div className="w-8 h-1 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full animate-pulse"></div>
            <div className="w-6 h-1 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-pulse delay-300"></div>
            <div className="w-10 h-1 bg-gradient-to-r from-pink-400 to-blue-400 rounded-full animate-pulse delay-600"></div>
          </div>
        </div>

        {/* Bottom accent line */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 opacity-60"></div>
      </div>

      {/* Additional floating elements */}
      <div className="absolute top-4 right-4 w-2 h-2 bg-white/40 rounded-full animate-ping"></div>
      <div className="absolute bottom-4 left-4 w-1.5 h-1.5 bg-white/30 rounded-full animate-bounce"></div>
    </div>
  );
};

export default ProfileSection;