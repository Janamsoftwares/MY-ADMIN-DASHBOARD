import React, { useState, useRef } from 'react';
import { Settings as SettingsIcon, Palette, User, Moon, Sun, Monitor, Save, Upload, Camera } from 'lucide-react';
import Swal from 'sweetalert2';

interface SettingsProps {
  onThemeChange?: (theme: string) => void;
  onProfileUpdate?: (profileData: any) => void;
}

const Settings: React.FC<SettingsProps> = ({ onThemeChange, onProfileUpdate }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [theme, setTheme] = useState(localStorage.getItem('adminTheme') || 'light');
  const [accentColor, setAccentColor] = useState(localStorage.getItem('adminAccentColor') || 'indigo');
  const [profileImage, setProfileImage] = useState<string | null>(
    localStorage.getItem('adminProfileImage')
  );
  const [adminName, setAdminName] = useState(
    localStorage.getItem('adminName') || 'Julius Kamau'
  );
  const [adminTitle, setAdminTitle] = useState(
    localStorage.getItem('adminTitle') || 'Chief Technology Officer'
  );
  const [adminEmail, setAdminEmail] = useState(
    localStorage.getItem('adminEmail') || 'julius@drnet.co.ke'
  );
  const [adminPhone, setAdminPhone] = useState(
    localStorage.getItem('adminPhone') || '+254 701 782 354'
  );
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    localStorage.setItem('adminTheme', newTheme);
    onThemeChange?.(newTheme);
    
    // Apply theme to document
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleAccentColorChange = (color: string) => {
    setAccentColor(color);
    localStorage.setItem('adminAccentColor', color);
    
    Swal.fire({
      title: 'Color Updated!',
      text: 'Accent color has been changed successfully.',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        Swal.fire('Error', 'Image size should be less than 5MB', 'error');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setProfileImage(imageUrl);
        localStorage.setItem('adminProfileImage', imageUrl);
        Swal.fire({
          title: 'Success!',
          text: 'Profile picture updated successfully!',
          icon: 'success',
          timer: 2000,
          showConfirmButton: false,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white'
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProfileSave = () => {
    localStorage.setItem('adminName', adminName);
    localStorage.setItem('adminTitle', adminTitle);
    localStorage.setItem('adminEmail', adminEmail);
    localStorage.setItem('adminPhone', adminPhone);
    
    onProfileUpdate?.({ 
      name: adminName, 
      title: adminTitle, 
      email: adminEmail, 
      phone: adminPhone, 
      image: profileImage 
    });
    
    Swal.fire({
      title: 'Success!',
      text: 'Profile updated successfully!',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const removeProfileImage = () => {
    setProfileImage(null);
    localStorage.removeItem('adminProfileImage');
    Swal.fire({
      title: 'Removed!',
      text: 'Profile picture removed successfully!',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    });
  };

  const accentColors = [
    { name: 'Indigo', value: 'indigo', color: 'bg-indigo-500' },
    { name: 'Purple', value: 'purple', color: 'bg-purple-500' },
    { name: 'Blue', value: 'blue', color: 'bg-blue-500' },
    { name: 'Green', value: 'green', color: 'bg-green-500' },
    { name: 'Pink', value: 'pink', color: 'bg-pink-500' },
    { name: 'Red', value: 'red', color: 'bg-red-500' },
    { name: 'Yellow', value: 'yellow', color: 'bg-yellow-500' },
    { name: 'Teal', value: 'teal', color: 'bg-teal-500' }
  ];

  const tabs = [
    { id: 'profile', name: 'Profile', icon: User },
    { id: 'appearance', name: 'Appearance', icon: Palette },
    { id: 'system', name: 'System', icon: SettingsIcon }
  ];

  return (
    <div className="space-y-8">
      <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
        Settings
      </h3>
      
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg overflow-hidden">
        {/* Tab Navigation */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <h4 className="text-xl font-semibold text-gray-800">Profile Information</h4>
              
              {/* Profile Picture Section */}
              <div className="flex items-center space-x-6">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg">
                    {profileImage ? (
                      <img 
                        src={profileImage} 
                        alt="Profile" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-12 h-12 text-white" />
                    )}
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-2 -right-2 bg-indigo-600 text-white p-2 rounded-full hover:bg-indigo-700 transition-colors duration-200 shadow-lg"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex-1">
                  <h5 className="text-lg font-medium text-gray-800">Profile Picture</h5>
                  <p className="text-sm text-gray-600 mb-3">Upload a new profile picture or remove the current one.</p>
                  <div className="flex space-x-3">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-200"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Upload New</span>
                    </button>
                    {profileImage && (
                      <button
                        onClick={removeProfileImage}
                        className="px-4 py-2 text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors duration-200"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
                
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>

              {/* Profile Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input
                    type="text"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter your full name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Job Title</label>
                  <input
                    type="text"
                    value={adminTitle}
                    onChange={(e) => setAdminTitle(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter your job title"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter your email"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter your phone number"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleProfileSave}
                  className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Profile</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="space-y-6">
              <h4 className="text-xl font-semibold text-gray-800">Appearance Settings</h4>
              
              {/* Theme Selection */}
              <div>
                <h5 className="text-lg font-medium text-gray-800 mb-3">Theme</h5>
                <div className="grid grid-cols-3 gap-4">
                  <button
                    onClick={() => handleThemeChange('light')}
                    className={`p-4 border-2 rounded-lg transition-all duration-200 ${
                      theme === 'light' 
                        ? 'border-indigo-500 bg-indigo-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Sun className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                    <p className="font-medium">Light</p>
                  </button>
                  
                  <button
                    onClick={() => handleThemeChange('dark')}
                    className={`p-4 border-2 rounded-lg transition-all duration-200 ${
                      theme === 'dark' 
                        ? 'border-indigo-500 bg-indigo-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Moon className="w-8 h-8 mx-auto mb-2 text-indigo-500" />
                    <p className="font-medium">Dark</p>
                  </button>
                  
                  <button
                    onClick={() => handleThemeChange('system')}
                    className={`p-4 border-2 rounded-lg transition-all duration-200 ${
                      theme === 'system' 
                        ? 'border-indigo-500 bg-indigo-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Monitor className="w-8 h-8 mx-auto mb-2 text-gray-500" />
                    <p className="font-medium">System</p>
                  </button>
                </div>
              </div>

              {/* Accent Color Selection */}
              <div>
                <h5 className="text-lg font-medium text-gray-800 mb-3">Accent Color</h5>
                <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
                  {accentColors.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => handleAccentColorChange(color.value)}
                      className={`relative p-3 rounded-lg transition-all duration-200 ${
                        accentColor === color.value 
                          ? 'ring-2 ring-offset-2 ring-gray-400' 
                          : 'hover:scale-105'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full ${color.color} mx-auto`}></div>
                      <p className="text-xs mt-1 font-medium">{color.name}</p>
                      {accentColor === color.value && (
                        <div className="absolute top-1 right-1 w-3 h-3 bg-white rounded-full flex items-center justify-center">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'system' && (
            <div className="space-y-6">
              <h4 className="text-xl font-semibold text-gray-800">System Settings</h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h5 className="font-medium text-gray-800">Auto-refresh Dashboard</h5>
                    <p className="text-sm text-gray-600">Automatically refresh dashboard data every 30 seconds</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h5 className="font-medium text-gray-800">Email Notifications</h5>
                    <p className="text-sm text-gray-600">Receive email alerts for new bookings and user activities</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h5 className="font-medium text-gray-800">Data Export</h5>
                    <p className="text-sm text-gray-600">Allow CSV export of user and booking data</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>
              </div>

              <div className="pt-6 border-t border-gray-200">
                <h5 className="text-lg font-medium text-gray-800 mb-3">Danger Zone</h5>
                <div className="space-y-3">
                  <button className="w-full p-3 text-left border border-red-300 rounded-lg hover:bg-red-50 transition-colors duration-200">
                    <h6 className="font-medium text-red-800">Clear All Data</h6>
                    <p className="text-sm text-red-600">Remove all users and bookings from the system</p>
                  </button>
                  
                  <button className="w-full p-3 text-left border border-red-300 rounded-lg hover:bg-red-50 transition-colors duration-200">
                    <h6 className="font-medium text-red-800">Reset Settings</h6>
                    <p className="text-sm text-red-600">Reset all settings to default values</p>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;