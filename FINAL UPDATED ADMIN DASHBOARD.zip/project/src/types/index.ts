export interface User {
  _id: string;
  name: string;
  phone: string;
  location: string;
  subscriptionAmount: number;
  routerCost: number;
  expiryDate: string;
  paidSubscription: boolean;
  paymentDate: string;
  package: string;
  isDeleted?: boolean;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  package: string;
  message: string;
  date: string;
  status?: 'pending' | 'processed' | 'contacted';
  installationDate?: string;
  preferredTime?: string;
}

export interface Invoice {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  userLocation: string;
  amount: number;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  status: string;
}