import { User, Booking } from '../types';

const USERS_KEY = 'drnet_users';
const BOOKINGS_KEY = 'drnet_bookings';

export const storageUtils = {
  getUsers: (): User[] => {
    try {
      const data = localStorage.getItem(USERS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveUsers: (users: User[]): void => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  getBookings: (): Booking[] => {
    try {
      const data = localStorage.getItem(BOOKINGS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveBookings: (bookings: Booking[]): void => {
    localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
  },

  // Sync bookings from website form submissions
  syncWebsiteBookings: (): Booking[] => {
    try {
      const websiteBookings = localStorage.getItem(BOOKINGS_KEY);
      if (websiteBookings) {
        const bookings = JSON.parse(websiteBookings);
        // Ensure all bookings have the required status field
        return bookings.map((booking: any) => ({
          ...booking,
          status: booking.status || 'pending'
        }));
      }
      return [];
    } catch (error) {
      console.error('Error syncing website bookings:', error);
      return [];
    }
  },

  clearAll: (): void => {
    localStorage.removeItem(USERS_KEY);
    localStorage.removeItem(BOOKINGS_KEY);
  }
};