# Website Integration Instructions

## How to Connect Your Main Website to the Admin Dashboard

To connect your main Dr.Net website booking form to this admin dashboard, follow these steps:

### 1. Update Your Website's Booking Form Script

Replace the existing JavaScript in your main website's booking form section with this updated code:

```html
<!-- ✅ Updated JS Script for Website Integration -->
<script>
  document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons(); // Load Lucide icons

    const form = document.getElementById("installationForm");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const formData = {
        name: document.getElementById("name").value.trim(),
        phone: document.getElementById("phone").value.trim(),
        email: document.getElementById("email").value.trim(),
        package: document.getElementById("package").value,
        location: document.getElementById("location").value.trim() || document.getElementById("exactLocation").value.trim(),
        exactLocation: document.getElementById("exactLocation").value.trim(),
        message: document.getElementById("extraNotes").value.trim() || "No additional notes provided",
        date: new Date().toISOString().split('T')[0],
        id: 'booking_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
        status: 'pending'
      };

      if (!formData.location) {
        alert("📍 Please select your area from the coverage section.");
        return;
      }

      try {
        // Save to localStorage (this will sync with admin dashboard)
        const existingBookings = JSON.parse(localStorage.getItem('drnet_bookings') || '[]');
        existingBookings.push(formData);
        localStorage.setItem('drnet_bookings', JSON.stringify(existingBookings));

        // Show success message
        document.getElementById("successMessage").textContent = `Dear ${formData.name}, your booking has been submitted to Dr.Net Technology Labs. We will contact you shortly.`;
        document.getElementById("successModal").classList.remove("hidden");
        
        // Reset form
        form.reset();
        document.getElementById("selectedAreaDisplay")?.classList.add("hidden");
        
        console.log("✅ Booking saved successfully:", formData);
        
      } catch (err) {
        console.error("❌ Error saving booking:", err);
        alert("❌ There was an error submitting your booking. Please try again.");
      }
    });
  });

  function closeSuccessModal() {
    document.getElementById("successModal").classList.add("hidden");
  }
</script>
```

### 2. Remove Backend Dependencies

Remove these lines from your main website since we're using localStorage instead of a backend:

```javascript
// ❌ Remove this fetch call
const res = await fetch("http://localhost:5000/api/bookings", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(formData)
});
```

### 3. How It Works

1. **Form Submission**: When customers fill out the booking form on your main website, the data is saved to the browser's localStorage.

2. **Data Sync**: The admin dashboard automatically checks for new bookings every 5 seconds and syncs them.

3. **Real-time Updates**: New bookings appear in the admin dashboard's "Website Bookings" section automatically.

4. **Status Management**: You can edit, delete, and change the status of bookings (Pending → Contacted → Processed).

### 4. Deployment Steps

1. **Update your main website** with the new JavaScript code above
2. **Deploy your admin dashboard** to Netlify
3. **Test the integration** by submitting a booking on your main website
4. **Check the admin dashboard** to see the new booking appear

### 5. Data Persistence

- All booking data is stored in the browser's localStorage
- Data persists between browser sessions
- Both your main website and admin dashboard use the same storage key (`drnet_bookings`)
- You can export booking data as needed from the admin dashboard

### 6. Security Notes

- This solution works for static hosting (Netlify)
- Data is stored locally in the browser
- For production use with multiple admin users, consider upgrading to a backend solution
- The current setup is perfect for single-admin management

### 7. Testing

To test the integration:

1. Open your main website
2. Fill out and submit a booking form
3. Open the admin dashboard
4. Navigate to "Website Bookings"
5. You should see the new booking appear

The booking will include all form data plus automatic fields like date, ID, and status.