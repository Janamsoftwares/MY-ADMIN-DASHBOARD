// Booking handler for the main website
// This script will be included in your main website to handle form submissions

class BookingManager {
  constructor() {
    this.storageKey = 'drnet_bookings';
    this.init();
  }

  init() {
    // Listen for form submissions
    document.addEventListener('DOMContentLoaded', () => {
      const form = document.getElementById('installationForm');
      if (form) {
        form.addEventListener('submit', (e) => this.handleFormSubmission(e));
      }
    });
  }

  handleFormSubmission(event) {
    event.preventDefault();
    
    const formData = {
      name: document.getElementById('name').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      email: document.getElementById('email').value.trim(),
      package: document.getElementById('package').value,
      location: document.getElementById('location').value.trim() || document.getElementById('exactLocation').value.trim(),
      exactLocation: document.getElementById('exactLocation').value.trim(),
      message: document.getElementById('extraNotes').value.trim() || 'No additional notes provided',
      date: new Date().toISOString().split('T')[0],
      id: this.generateId(),
      status: 'pending'
    };

    // Validate required fields
    if (!formData.name || !formData.phone || !formData.package || !formData.location) {
      alert('📍 Please fill in all required fields.');
      return;
    }

    try {
      // Save to localStorage
      this.saveBooking(formData);
      
      // Show success message
      this.showSuccessMessage(formData.name);
      
      // Reset form
      document.getElementById('installationForm').reset();
      document.getElementById('selectedAreaDisplay')?.classList.add('hidden');
      
    } catch (error) {
      console.error('Error saving booking:', error);
      alert('❌ There was an error submitting your booking. Please try again.');
    }
  }

  saveBooking(bookingData) {
    // Get existing bookings
    const existingBookings = this.getBookings();
    
    // Add new booking
    existingBookings.push(bookingData);
    
    // Save back to localStorage
    localStorage.setItem(this.storageKey, JSON.stringify(existingBookings));
    
    console.log('Booking saved successfully:', bookingData);
  }

  getBookings() {
    try {
      const bookings = localStorage.getItem(this.storageKey);
      return bookings ? JSON.parse(bookings) : [];
    } catch (error) {
      console.error('Error retrieving bookings:', error);
      return [];
    }
  }

  generateId() {
    return 'booking_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  showSuccessMessage(customerName) {
    const successMessage = `Dear ${customerName}, your booking has been submitted to Dr.Net Technology Labs. We will contact you shortly.`;
    
    // Update the success modal message
    const successMessageElement = document.getElementById('successMessage');
    if (successMessageElement) {
      successMessageElement.textContent = successMessage;
    }
    
    // Show the success modal
    const successModal = document.getElementById('successModal');
    if (successModal) {
      successModal.classList.remove('hidden');
    }
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      this.closeSuccessModal();
    }, 5000);
  }

  closeSuccessModal() {
    const successModal = document.getElementById('successModal');
    if (successModal) {
      successModal.classList.add('hidden');
    }
  }
}

// Initialize the booking manager
const bookingManager = new BookingManager();

// Make closeSuccessModal available globally for the close button
window.closeSuccessModal = () => bookingManager.closeSuccessModal();

// Export for use in other scripts if needed
window.BookingManager = BookingManager;